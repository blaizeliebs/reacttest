import React from 'react';
import { render } from 'react-dom';

import MyContainerApp from 'MyContainerApp';

render (<MyContainerApp />, document.getElementById('app'))